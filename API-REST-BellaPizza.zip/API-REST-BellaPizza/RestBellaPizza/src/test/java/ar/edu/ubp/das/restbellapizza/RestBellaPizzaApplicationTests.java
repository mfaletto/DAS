package ar.edu.ubp.das.restbellapizza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestBellaPizzaApplicationTests {

    @Test
    void contextLoads() {
    }

}
