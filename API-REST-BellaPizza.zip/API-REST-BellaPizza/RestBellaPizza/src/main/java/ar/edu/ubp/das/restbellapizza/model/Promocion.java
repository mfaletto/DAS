package ar.edu.ubp.das.restbellapizza.model;

public class Promocion {
    private Long id;
    private String titulo;
    private String descripcion;
    private Long restauranteId;
    private String restauranteNombre;
    private String imagenUrl;

    public Promocion() {}

    // Constructor con todos los campos
    public Promocion(Long id, String titulo, String descripcion, Long restauranteId, String restauranteNombre, String imagenUrl) {
        this.id = id;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.restauranteId = restauranteId;
        this.restauranteNombre = restauranteNombre;
        this.imagenUrl = imagenUrl;
    }

    // ⬅️ ¡ESTOS SON LOS MÉTODOS QUE FALTAN! ⬅️

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public Long getRestauranteId() { return restauranteId; }
    public void setRestauranteId(Long restauranteId) { this.restauranteId = restauranteId; }

    public String getRestauranteNombre() { return restauranteNombre; }
    public void setRestauranteNombre(String restauranteNombre) { this.restauranteNombre = restauranteNombre; }

    public String getImagenUrl() { return imagenUrl; }
    public void setImagenUrl(String imagenUrl) { this.imagenUrl = imagenUrl; }
}