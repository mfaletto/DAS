package ar.edu.ubp.das.restbellapizza.controller;

import ar.edu.ubp.das.restbellapizza.model.Promocion;
import java.util.Arrays;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
// ⚠️ CORS: Permite peticiones desde el servidor de desarrollo de Angular (Puerto 4200)
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/promociones") // ⬅️ La ruta final será /api/v1/promociones
public class PromocionController {

    // PromocionController.java (SOLO la sección de datos)

    // 1. SIMULACIÓN DE DATOS (Hasta implementar SQL Server)
    private final List<Promocion> promociones = Arrays.asList(
            // Promoción 1: Menú Estudiantil (Pizza)
            new Promocion(
                    1L,
                    "Menú Estudiantil",
                    "¡25% OFF en pizzas personales de lunes a viernes!",
                    10L,
                    "Bella Pizza Central",
                    "https://plus.unsplash.com/premium_photo-1661883237884-263e8de8869b?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&q=80&w=1189" // Imagen de pizza
            ),

            // Promoción 2: Cena Romántica IA (Gourmet)
            new Promocion(
                    2L,
                    "Cena Romántica IA",
                    "Una descripción sugerida por nuestra IA: ambiente ideal y vino tinto de regalo.",
                    20L,
                    "Ristorino Gourmet",
                    "https://plus.unsplash.com/premium_photo-1661433201283-fcb240e88ad4?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&q=80&w=1170" // Imagen de plato gourmet
            ),

            // Promoción 3: Postre Doble
            new Promocion(
                    3L,
                    "Postre Doble",
                    "Pide un plato principal y obtén el postre para compartir. Válido fines de semana.",
                    10L,
                    "Bella Pizza Central",
                    "https://images.unsplash.com/photo-1481833761820-0509d3217039?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&q=80&w=1170" // Imagen de postre
            )
    );

    /**
     * ENDPOINT: GET /api/v1/promociones
     * Propósito: Listar promociones para la página de inicio.
     */
    @GetMapping("")
    public List<Promocion> getPromociones() {
        return promociones;
    }

    // Clase auxiliar para recibir el cuerpo del POST del clic
    public static class ClickRequest {
        private Long promocionId;

        public Long getPromocionId() { return promocionId; }
        public void setPromocionId(Long promocionId) { this.promocionId = promocionId; }
    }

    /**
     * ENDPOINT: POST /api/v1/promociones/clics-ia
     * Propósito: Registrar el clic para monetización (Req 50).
     */
    @PostMapping("/clics-ia")
    public ResponseEntity<?> registrarClic(@RequestBody ClickRequest request) {
        Long promocionId = request.getPromocionId();

        // SIMULACIÓN DE REGISTRO
        System.out.println("--- REGISTRO RISTORINO ---");
        System.out.println("Registrado clic en Promoción ID: " + promocionId);
        System.out.println("---------------------------");

        return ResponseEntity.ok().build(); // Devuelve 200 OK
    }
}
