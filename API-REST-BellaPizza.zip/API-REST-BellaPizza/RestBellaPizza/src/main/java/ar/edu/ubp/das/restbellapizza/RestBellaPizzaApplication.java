package ar.edu.ubp.das.restbellapizza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestBellaPizzaApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestBellaPizzaApplication.class, args);
    }

}
